package com.demofix.mobile

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.media.AudioAttributes
import android.media.SoundPool
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MainActivity : Activity() {
    private var demo1: ByteArray? = null
    private var demo2: ByteArray? = null
    private var demo1Name = ""
    private var demo2Name = ""
    private lateinit var status: TextView
    private lateinit var demo1Card: TextView
    private lateinit var demo2Card: TextView
    private val pick1 = 10
    private val pick2 = 11
    private val bg = Color.rgb(10, 12, 15)
    private val card = Color.rgb(20, 24, 29)
    private val green = Color.rgb(32, 212, 107)
    private val white = Color.rgb(245, 247, 250)
    private val muted = Color.rgb(164, 173, 184)
    private lateinit var soundPool: SoundPool
    private var clickSound = 0

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val audioAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        soundPool = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(audioAttrs).build()
        clickSound = soundPool.load(this, R.raw.click, 1)

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(28))
        }
        scroll.addView(root)

        val logo = ImageView(this).apply {
            setImageResource(com.demofix.mobile.R.drawable.demofix_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Logo DemoFix"
        }
        root.addView(logo, lp(-1, dp(340), 0, 0, 0, 8))
        scroll.setOnScrollChangeListener { _, _, scrollY, _, _ ->
            val progress = (scrollY.toFloat() / dp(260).toFloat()).coerceIn(0f, 1f)
            logo.alpha = 1f - (progress * 0.88f)
            logo.translationY = -scrollY * 0.16f
        }

        val brand = TextView(this).apply {
            text = "DemoFix"
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            gravity = Gravity.CENTER
        }
        root.addView(brand, lp(-1, -2, 0, 0, 0, 4))

        root.addView(TextView(this).apply {
            text = "Repare demos Xash3D / GoldSrc direto no celular"
            textSize = 15f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }, lp(-1, -2, 0, 0, 0, 18))

        val how = TextView(this).apply {
            text = "⚡  REPARO AUTOMÁTICO"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(green)
            letterSpacing = .04f
        }
        root.addView(how, lp(-1, -2, 0, 0, 0, 8))

        root.addView(TextView(this).apply {
            text = "Selecione uma demo. Se você tiver duas demos da mesma partida, adicione a segunda e o DemoFix escolherá sozinho qual startup usar."
            textSize = 14f
            setTextColor(muted)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(card, 14)
        }, lp(-1, -2, 0, 0, 0, 16))

        demo1Card = fileCard("DEMO 1", "Nenhuma demo selecionada")
        root.addView(demo1Card, lp(-1, dp(72), 0, 0, 0, 8))
        demo1Card.setOnClickListener { choose(pick1) }
        addPressAnimation(demo1Card)

        demo2Card = fileCard("DEMO 2  •  OPCIONAL", "Toque para adicionar outra demo")
        root.addView(demo2Card, lp(-1, dp(72), 0, 0, 0, 12))
        demo2Card.setOnClickListener { choose(pick2) }
        addPressAnimation(demo2Card)

        val repair = TextView(this).apply {
            text = "⚡  CORRIGIR AUTOMATICAMENTE"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(5, 20, 10))
            gravity = Gravity.CENTER
            background = rounded(green, 16)
            isClickable = true
            setPadding(dp(10), 0, dp(10), 0)
        }
        root.addView(repair, lp(-1, dp(58), 0, 0, 0, 16))
        repair.setOnClickListener { repairAutomatically() }
        addPressAnimation(repair)

        status = TextView(this).apply {
            text = "Pronto para reparar."
            textSize = 14f
            setTextColor(white)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(card, 14)
        }
        root.addView(status, lp(-1, -2, 0, 0, 0, 16))

        val infoTitle = TextView(this).apply {
            text = "COMO FUNCIONA"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            letterSpacing = .08f
        }
        root.addView(infoTitle, lp(-1, -2, 0, 0, 0, 8))
        root.addView(TextView(this).apply {
            text = "• 1 demo: tenta reparar automaticamente.\n• 2 demos: identifica a que tem o startup completo e usa ela automaticamente.\n• A demo original nunca é sobrescrita."
            textSize = 14f
            setTextColor(muted)
            setLineSpacing(2f, 1.05f)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(card, 14)
        }, lp(-1, -2, 0, 0, 0, 12))

        root.addView(TextView(this).apply {
            text = "DemoFix • Xash3D / GoldSrc"
            textSize = 12f
            setTextColor(Color.rgb(105, 114, 124))
            gravity = Gravity.CENTER
        }, lp(-1, -2, 0, 0, 0, 0))

        setContentView(scroll)
    }

    private fun addPressAnimation(view: View) {
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate().scaleX(0.96f).scaleY(0.96f).setDuration(70).start()
                    playClick()
                    false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                    false
                }
                else -> false
            }
        }
    }

    private fun playClick() {
        if (clickSound != 0) soundPool.play(clickSound, 0.45f, 0.45f, 1, 0, 1f)
    }

    override fun onDestroy() {
        soundPool.release()
        super.onDestroy()
    }

    private fun fileCard(label: String, value: String): TextView = TextView(this).apply {
        text = "$label\n$value"
        textSize = 14f
        setTextColor(white)
        setPadding(dp(16), dp(10), dp(16), dp(10))
        gravity = Gravity.CENTER_VERTICAL
        background = rounded(card, 14)
    }

    private fun lp(w: Int, h: Int, l: Int, t: Int, r: Int, b: Int) = LinearLayout.LayoutParams(w, h).apply {
        setMargins(dp(l), dp(t), dp(r), dp(b))
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun choose(code: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/octet-stream"
            addCategory(Intent.CATEGORY_OPENABLE)
        }, code)
    }

    override fun onActivityResult(req: Int, result: Int, data: Intent?) {
        super.onActivityResult(req, result, data)
        if (result != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                if (req == pick1) { demo1 = input.readBytes(); demo1Name = displayName(uri) }
                else { demo2 = input.readBytes(); demo2Name = displayName(uri) }
            }
            demo1Card.text = "DEMO 1\n${if (demo1Name.isEmpty()) "Nenhuma demo selecionada" else demo1Name}"
            demo2Card.text = "DEMO 2  •  OPCIONAL\n${if (demo2Name.isEmpty()) "Toque para adicionar outra demo" else demo2Name}"
            status.text = "✓ Demo carregada. Toque em CORRIGIR AUTOMATICAMENTE."
        } catch (e: Exception) { status.text = "❌ Não consegui ler a demo: ${e.message}" }
    }

    private fun displayName(uri: Uri): String = uri.lastPathSegment?.substringAfterLast('/') ?: "demo.dem"

    private data class Info(
        val map: String, val dir: Int, val startupOffset: Int, val startupLength: Int,
        val normalOffset: Int, val normalLength: Int, val time: Float, val frames: Int
    )

    private fun i32(a: ByteArray, o: Int) = ByteBuffer.wrap(a, o, 4).order(ByteOrder.LITTLE_ENDIAN).int
    private fun f32(a: ByteArray, o: Int) = ByteBuffer.wrap(a, o, 4).order(ByteOrder.LITTLE_ENDIAN).float
    private fun text(a: ByteArray, o: Int, n: Int): String {
        var end = o
        while (end < o + n && end < a.size && a[end].toInt() != 0) end++
        return a.copyOfRange(o, end).toString(Charsets.ISO_8859_1)
    }

    private fun info(a: ByteArray): Info {
        require(a.size >= 396) { "Arquivo DEM inválido ou pequeno." }
        val dir = i32(a, 212)
        require(dir >= 216 && dir + 180 <= a.size) { "Diretório da demo inválido." }
        require(i32(a, dir) == 2) { "Diretório inválido: não encontrei 2 entradas." }
        val d0 = dir + 4
        val d1 = d0 + 88
        return Info(text(a, 20, 64), dir, i32(a, d0 + 12), i32(a, d0 + 16), i32(a, d1 + 12), i32(a, d1 + 16), f32(a, d1 + 4), i32(a, d1 + 8))
    }

    private fun replaceAll(src: ByteArray, old: ByteArray, new: ByteArray): Int {
        if (old.isEmpty() || old.size != new.size) return 0
        var count = 0; var p = 0
        while (p <= src.size - old.size) {
            var ok = true
            for (i in old.indices) if (src[p + i] != old[i]) { ok = false; break }
            if (ok) { for (i in new.indices) src[p + i] = new[i]; count++; p += old.size } else p++
        }
        return count
    }

    private fun repairAutomatically() {
        try {
            val a = demo1 ?: throw Exception("Selecione pelo menos uma demo.")
            val ia = info(a)
            val b = demo2
            if (b == null) {
                if (ia.startupLength <= 1000) throw Exception("Esta demo perdeu o startup. Adicione a outra demo da mesma partida para o reparo automático.")
                val out = rebuild(a, ia, a, ia)
                saveAndShare(out, demo1Name, "startup já estava completo; diretório reconstruído automaticamente")
                return
            }
            val ib = info(b)
            require(ia.map.equals(ib.map, ignoreCase = true)) { "As duas demos precisam ser do mesmo mapa/partida." }
            val ref: ByteArray; val ri: Info; val target: ByteArray; val ti: Info; val targetName: String
            if (ia.startupLength >= ib.startupLength) { ref = a; ri = ia; target = b; ti = ib; targetName = demo2Name }
            else { ref = b; ri = ib; target = a; ti = ia; targetName = demo1Name }
            require(ri.startupLength > 1000) { "Nenhuma das duas demos tem startup completo." }
            val out = rebuild(target, ti, ref, ri)
            saveAndShare(out, targetName, "startup completo escolhido automaticamente entre as duas demos")
        } catch (e: Exception) { status.text = "❌ ${e.message}" }
    }

    private fun rebuild(target: ByteArray, ti: Info, reference: ByteArray, ri: Info): ByteArray {
        val startup = reference.copyOfRange(ri.startupOffset, ri.startupOffset + ri.startupLength)
        val oldMap = ("maps/" + ri.map + ".bsp").toByteArray(Charsets.ISO_8859_1)
        val newMap = ("maps/" + ti.map + ".bsp").toByteArray(Charsets.ISO_8859_1)
        if (!ri.map.equals(ti.map, ignoreCase = true)) replaceAll(startup, oldMap, newMap)
        replaceAll(startup, "stop\n".toByteArray(), "echo\n".toByteArray())
        val stream = target.copyOfRange(ti.normalOffset, ti.normalOffset + ti.normalLength)
        val out = ByteArray(216 + startup.size + stream.size + 180)
        target.copyInto(out, 0, 0, 216); startup.copyInto(out, 216); stream.copyInto(out, 216 + startup.size)
        val dv = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        val dir = 216 + startup.size + stream.size
        dv.putInt(212, dir); dv.putInt(dir, 2)
        val d0 = dir + 4
        dv.putInt(d0, 0); dv.putFloat(d0 + 4, 0f); dv.putInt(d0 + 8, 0); dv.putInt(d0 + 12, 216); dv.putInt(d0 + 16, startup.size); dv.putInt(d0 + 20, 0)
        val d1 = d0 + 88
        dv.putInt(d1, 1); dv.putFloat(d1 + 4, ti.time); dv.putInt(d1 + 8, ti.frames); dv.putInt(d1 + 12, 216 + startup.size); dv.putInt(d1 + 16, stream.size); dv.putInt(d1 + 20, 0)
        val mapBytes = ti.map.toByteArray(Charsets.ISO_8859_1)
        java.util.Arrays.fill(out, 20, 84, 0.toByte()); mapBytes.copyInto(out, 20, 0, minOf(63, mapBytes.size))
        java.util.Arrays.fill(out, 84, 148, 0.toByte()); mapBytes.copyInto(out, 84, 0, minOf(63, mapBytes.size))
        return out
    }

    private fun saveAndShare(bytes: ByteArray, originalName: String, method: String) {
        val base = originalName.ifEmpty { "demo.dem" }.replace(Regex("\\.dem$", RegexOption.IGNORE_CASE), "")
        val file = File(cacheDir, base + "_repaired.dem")
        file.writeBytes(bytes)
        status.text = "✅ DEMO CORRIGIDA!\n\n$method\n\nArquivo pronto: ${file.name}"
        val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Salvar/compartilhar demo corrigida"))
    }
}
