package com.demofix.mobile

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MainActivity : Activity() {
    private var first: ByteArray? = null
    private var second: ByteArray? = null
    private var firstName = ""
    private var secondName = ""
    private lateinit var status: TextView
    private val pick1 = 10
    private val pick2 = 11

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
            setBackgroundColor(Color.rgb(13,15,18))
        }
        val title = TextView(this).apply {
            text = "DemoFix"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(title)
        val sub = TextView(this).apply {
            text = "Corrija demos Xash3D / GoldSrc direto no celular"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0,0,0,20)
        }
        root.addView(sub)

        val b1 = button("Selecionar DEMO 1")
        val b2 = button("Selecionar DEMO 2")
        val repair = button("⚡ CORRIGIR DUAS DEMOS")
        repair.setTextColor(Color.rgb(5,20,10))
        repair.setBackgroundColor(Color.rgb(32,212,107))
        status = TextView(this).apply {
            text = "Selecione as duas demos da mesma partida."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0,24,0,0)
        }
        root.addView(b1); root.addView(b2); root.addView(repair); root.addView(status)
        b1.setOnClickListener { choose(pick1) }
        b2.setOnClickListener { choose(pick2) }
        repair.setOnClickListener { repairPair() }
        setContentView(root)
    }

    private fun button(t:String)=Button(this).apply {
        text=t; isAllCaps=false
        setTextColor(Color.WHITE)
        setPadding(12,10,12,10)
        layoutParams=LinearLayout.LayoutParams(-1,55).apply { setMargins(0,8,0,8) }
    }

    private fun choose(code:Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type="application/octet-stream"; addCategory(Intent.CATEGORY_OPENABLE)
        }, code)
    }

    override fun onActivityResult(req:Int,res:Int,data:Intent?) {
        super.onActivityResult(req,res,data)
        if(res!=RESULT_OK || data?.data==null) return
        val u=data.data!!
        contentResolver.openInputStream(u)?.use { bytes ->
            if(req==pick1){ first=bytes.readBytes(); firstName=displayName(u) }
            else { second=bytes.readBytes(); secondName=displayName(u) }
        }
        status.text="DEMO 1: ${firstName.ifEmpty{"—"}}\nDEMO 2: ${secondName.ifEmpty{"—"}}"
    }

    private fun displayName(u:Uri):String = u.lastPathSegment ?: "demo.dem"

    private data class Info(val map:String,val dir:Int,val sOff:Int,val sLen:Int,val nOff:Int,val nLen:Int,val time:Float,val frames:Int)
    private fun i32(a:ByteArray,o:Int)=ByteBuffer.wrap(a,o,4).order(ByteOrder.LITTLE_ENDIAN).int
    private fun f32(a:ByteArray,o:Int)=ByteBuffer.wrap(a,o,4).order(ByteOrder.LITTLE_ENDIAN).float
    private fun str(a:ByteArray,o:Int,n:Int):String {
        var e=o; while(e<o+n && e<a.size && a[e].toInt()!=0)e++
        return a.copyOfRange(o,e).toString(Charsets.ISO_8859_1)
    }
    private fun info(a:ByteArray):Info {
        require(a.size>=392){"Arquivo DEM inválido ou pequeno"}
        val dir=i32(a,212); require(dir>=216 && dir+180<=a.size){"Diretório da demo inválido"}
        require(i32(a,dir)==2){"Diretório da demo inválido (2 entradas esperadas)"}
        val e0=dir+4
        val e1=e0+88
        val map=str(a,20,64)
        return Info(map,dir,i32(a,e0+12),i32(a,e0+16),i32(a,e1+12),i32(a,e1+16),f32(a,e1+4),i32(a,e1+8))
    }

    private fun replaceAll(src:ByteArray, old:ByteArray, new:ByteArray):Int {
        var count=0; var p=0
        while(p<=src.size-old.size) {
            var ok=true
            for(i in old.indices) if(src[p+i]!=old[i]){ok=false;break}
            if(ok){for(i in new.indices)src[p+i]=new[i];count++;p+=old.size}else p++
        }
        return count
    }

    private fun repairPair(){
        try {
            val a=first ?: throw Exception("Selecione a DEMO 1.")
            val b=second ?: throw Exception("Selecione a DEMO 2.")
            val ia=info(a); val ib=info(b)
            val ref:ByteArray; val ri:Info; val target:ByteArray; val ti:Info; val targetName:String
            if(ia.sLen>=ib.sLen){ref=a;ri=ia;target=b;ti=ib;targetName=secondName}
            else {ref=b;ri=ib;target=a;ti=ia;targetName=firstName}
            require(ri.sLen>1000){"Nenhuma das demos parece ter startup completo."}

            var startup=ref.copyOfRange(ri.sOff,ri.sOff+ri.sLen)
            val oldMap=("maps/"+ri.map+".bsp").toByteArray(Charsets.ISO_8859_1)
            val newMap=("maps/"+ti.map+".bsp").toByteArray(Charsets.ISO_8859_1)
            replaceAll(startup,oldMap,newMap)

            // The known Xash3D fix: replace standalone stop\n with echo\n.
            val stop="stop\n".toByteArray()
            val echo="echo\n".toByteArray()
            val stops=replaceAll(startup,stop,echo)

            val stream=target.copyOfRange(ti.nOff,ti.nOff+ti.nLen)
            val out=ByteArray(216+startup.size+stream.size+180)
            target.copyInto(out,0,0,216)
            startup.copyInto(out,216)
            stream.copyInto(out,216+startup.size)
            val dv=ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
            val dir=216+startup.size+stream.size
            dv.putInt(212,dir)
            // entry 0
            dv.putInt(dir,2)
            // entry 0
            val d0=dir+4
            dv.putInt(d0,0); dv.putFloat(d0+4,0f); dv.putInt(d0+8,0)
            dv.putInt(d0+12,216); dv.putInt(d0+16,startup.size); dv.putInt(d0+20,0)
            // entry 1
            val d1=d0+88
            dv.putInt(d1,1); dv.putFloat(d1+4,ti.time); dv.putInt(d1+8,ti.frames)
            dv.putInt(d1+12,216+startup.size); dv.putInt(d1+16,stream.size); dv.putInt(d1+20,0)
            // preserve target header map/comment
            val mapBytes=ti.map.toByteArray()
            java.util.Arrays.fill(out,20,84,0.toByte()); mapBytes.copyInto(out,20,0,minOf(63,mapBytes.size))
            java.util.Arrays.fill(out,84,148,0.toByte()); mapBytes.copyInto(out,84,0,minOf(63,mapBytes.size))

            val name=(targetName.ifEmpty{"demo"}) .replace(Regex("\\.dem$"),"")+"_repaired.dem"
            val dirOut=getExternalFilesDir(null) ?: filesDir
            val file=java.io.File(dirOut,name); file.writeBytes(out)
            status.text="✅ CORRIGIDA!\n$stops ocorrência(s) stop → echo\n\nArquivo salvo em:\n${file.absolutePath}"
            share(file)
        } catch(e:Exception){ status.text="❌ ${e.message}" }
    }

    private fun share(file:java.io.File){
        val i=Intent(Intent.ACTION_SEND).apply{
            type="application/octet-stream"
            putExtra(Intent.EXTRA_STREAM,Uri.fromFile(file))
        }
        // FileProvider would be needed for strict Android versions; avoid auto-share if unavailable.
        // The file remains in app storage; a future version can expose SAF Save-As.
    }
}
