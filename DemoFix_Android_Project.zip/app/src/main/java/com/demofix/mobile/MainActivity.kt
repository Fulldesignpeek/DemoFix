package com.demofix.mobile

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.media.AudioAttributes
import android.media.SoundPool
import android.animation.ValueAnimator
import android.view.animation.DecelerateInterpolator
import android.widget.*
import androidx.core.content.FileProvider
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MainActivity : Activity() {
    private var demo1: ByteArray? = null
    private var demo2: ByteArray? = null
    private var demo1Name = ""
    private var demo2Name = ""
    private lateinit var status: TextView
    private lateinit var demo1Card: TextView
    private lateinit var demo2Card: TextView
    private lateinit var repairButton: FillButton
    private val pick1 = 10
    private val pick2 = 11
    private val bg = Color.rgb(10, 12, 15)
    private val card = Color.rgb(20, 24, 29)
    private val green = Color.rgb(32, 212, 107)
    private val red = Color.rgb(235, 67, 67)
    private val white = Color.rgb(245, 247, 250)
    private val muted = Color.rgb(164, 173, 184)
    private lateinit var soundPool: SoundPool
    private var clickSound = 0
    private var soundLoaded = false
    private var busy = false

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val audioAttrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        soundPool = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(audioAttrs).build()
        soundPool.setOnLoadCompleteListener { _, sampleId, statusCode ->
            if (statusCode == 0 && sampleId == clickSound) soundLoaded = true
        }
        clickSound = soundPool.load(this, R.raw.click, 1)

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
        }
        scroll.addView(root)

        val logo = ImageView(this).apply {
            setImageResource(R.drawable.demofix_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            contentDescription = "Logo DemoFix"
        }
        root.addView(logo, lp(-1, dp(300), 0, 0, 0, 4))
        scroll.setOnScrollChangeListener { _, _, scrollY, _, _ ->
            val progress = (scrollY.toFloat() / dp(230).toFloat()).coerceIn(0f, 1f)
            logo.alpha = 1f - (progress * 0.92f)
            logo.translationY = -scrollY * 0.14f
        }

        val brand = TextView(this).apply {
            text = "DemoFix"
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
            gravity = Gravity.CENTER
        }
        root.addView(brand, lp(-1, -2, 0, 0, 0, 3))

        root.addView(TextView(this).apply {
            text = "Repare demos Xash3D / GoldSrc direto no celular"
            textSize = 15f
            setTextColor(muted)
            gravity = Gravity.CENTER
        }, lp(-1, -2, 0, 0, 0, 16))

        root.addView(TextView(this).apply {
            text = "⚡  REPARO AUTOMÁTICO"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(green)
            letterSpacing = .04f
        }, lp(-1, -2, 0, 0, 0, 8))

        root.addView(TextView(this).apply {
            text = "Selecione uma demo. Se você tiver duas demos da mesma partida, adicione a segunda e o DemoFix escolherá sozinho qual startup usar."
            textSize = 14f
            setTextColor(muted)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(card, 14)
        }, lp(-1, -2, 0, 0, 0, 14))

        demo1Card = fileCard("DEMO 1", "Toque para selecionar uma demo")
        root.addView(demo1Card, lp(-1, dp(82), 0, 0, 0, 8))
        demo1Card.setOnClickListener { if (!busy) choose(pick1) }
        addPressAnimation(demo1Card)

        demo2Card = fileCard("DEMO 2  •  OPCIONAL", "Toque para adicionar outra demo")
        root.addView(demo2Card, lp(-1, dp(82), 0, 0, 0, 12))
        demo2Card.setOnClickListener { if (!busy) choose(pick2) }
        addPressAnimation(demo2Card)

        repairButton = FillButton(this).apply {
            label = "⚡  CORRIGIR AUTOMATICAMENTE"
            setTextColor(Color.rgb(5, 20, 10))
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setOnClickListener { if (!busy) startRepairAnimation() }
        }
        root.addView(repairButton, lp(-1, dp(62), 0, 0, 0, 14))
        addPressAnimation(repairButton)

        status = TextView(this).apply {
            text = "Pronto para reparar."
            textSize = 14f
            setTextColor(white)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(card, 14)
        }
        root.addView(status, lp(-1, -2, 0, 0, 0, 16))

        val infoTitle = TextView(this).apply {
            text = "COMO FUNCIONA"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            letterSpacing = .08f
        }
        root.addView(infoTitle, lp(-1, -2, 0, 0, 0, 8))
        root.addView(TextView(this).apply {
            text = "①  Analisa a demo\n②  Reconstrói o diretório\n③  Restaura o startup quando necessário\n④  Salva uma nova demo sem sobrescrever a original"
            textSize = 14f
            setTextColor(muted)
            setLineSpacing(2f, 1.08f)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(card, 14)
        }, lp(-1, -2, 0, 0, 0, 12))

        root.addView(TextView(this).apply {
            text = "DemoFix  •  Xash3D / GoldSrc  •  By Fulldesign"
            textSize = 12f
            setTextColor(Color.rgb(105, 114, 124))
            gravity = Gravity.CENTER
        }, lp(-1, -2, 0, 0, 0, 0))

        setContentView(scroll)
    }

    private fun addPressAnimation(view: View) {
        view.setOnTouchListener { v, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.animate().scaleX(0.97f).scaleY(0.97f).setDuration(65).start()
                    playClick()
                    false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                    false
                }
                else -> false
            }
        }
    }

    private fun playClick() {
        if (soundLoaded && clickSound != 0) soundPool.play(clickSound, 0.95f, 0.95f, 1, 0, 1f)
    }

    override fun onDestroy() {
        soundPool.release()
        super.onDestroy()
    }

    private fun fileCard(label: String, value: String): TextView = TextView(this).apply {
        text = "📄  $label\n$value"
        textSize = 14f
        setTextColor(white)
        setPadding(dp(16), dp(10), dp(16), dp(10))
        gravity = Gravity.CENTER_VERTICAL
        background = rounded(card, 16)
    }

    private fun setCardState(cardView: TextView, label: String, name: String, state: CardState) {
        val title = when (state) {
            CardState.SUCCESS -> "✓  $label  •  RESTAURADA"
            CardState.ERROR -> "✕  $label  •  NÃO RESTAURADA"
            CardState.LOADED -> "📄  $label  •  CARREGADA"
            CardState.NEUTRAL -> "📄  $label"
        }
        cardView.text = "$title\n${name.ifEmpty { "Toque para selecionar uma demo" }}"
        cardView.background = when (state) {
            CardState.SUCCESS -> outlined(Color.rgb(12, 42, 27), green, 16, 2)
            CardState.ERROR -> outlined(Color.rgb(48, 18, 20), red, 16, 2)
            CardState.LOADED, CardState.NEUTRAL -> rounded(card, 16)
        }
        cardView.setTextColor(if (state == CardState.ERROR) Color.rgb(255, 205, 205) else white)
    }

    private enum class CardState { NEUTRAL, LOADED, SUCCESS, ERROR }

    private fun startRepairAnimation() {
        val a = demo1 ?: run { setStatusError("Selecione pelo menos uma demo."); return }
        busy = true
        repairButton.isEnabled = false
        repairButton.resetProgress()
        repairButton.label = "⚙  ANALISANDO DEMO..."
        setStatusNeutral("① Analisando a demo...")
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2000L
            interpolator = DecelerateInterpolator()
            addUpdateListener { anim ->
                val p = anim.animatedValue as Float
                repairButton.setProgress(p)
                when {
                    p < .34f -> setStatusNeutral("① Analisando a demo...")
                    p < .67f -> setStatusNeutral("② Reconstruindo dados da gravação...")
                    else -> setStatusNeutral("③ Restaurando a demo...")
                }
            }
            doOnEnd {
                repairButton.label = "✓  FINALIZANDO..."
                try {
                    performRepair(a)
                } catch (e: Exception) {
                    setStatusError(e.message ?: "Não foi possível reparar a demo.")
                    if (demo1 != null) setCardState(demo1Card, "DEMO 1", demo1Name, CardState.ERROR)
                    if (demo2 != null) setCardState(demo2Card, "DEMO 2  •  OPCIONAL", demo2Name, CardState.ERROR)
                    repairButton.finish(false)
                    busy = false
                    repairButton.isEnabled = true
                }
            }
            start()
        }
    }

    private fun performRepair(a: ByteArray) {
        val ia = info(a)
        val b = demo2
        if (b == null) {
            if (ia.startupLength <= 1000) throw Exception("Esta demo perdeu o startup. Adicione a outra demo da mesma partida.")
            val out = rebuild(a, ia, a, ia)
            setCardState(demo1Card, "DEMO 1", demo1Name, CardState.SUCCESS)
            saveAndShare(out, demo1Name, "startup já estava completo; diretório reconstruído automaticamente")
            return
        }
        val ib = info(b)
        require(ia.map.equals(ib.map, ignoreCase = true)) { "As duas demos precisam ser do mesmo mapa/partida." }
        val ref: ByteArray; val ri: Info; val target: ByteArray; val ti: Info; val targetName: String; val targetCard: TextView
        if (ia.startupLength >= ib.startupLength) {
            ref = a; ri = ia; target = b; ti = ib; targetName = demo2Name; targetCard = demo2Card
        } else {
            ref = b; ri = ib; target = a; ti = ia; targetName = demo1Name; targetCard = demo1Card
        }
        require(ri.startupLength > 1000) { "Nenhuma das duas demos tem startup completo." }
        val out = rebuild(target, ti, ref, ri)
        setCardState(targetCard, if (targetCard == demo1Card) "DEMO 1" else "DEMO 2  •  OPCIONAL", targetName, CardState.SUCCESS)
        val refCard = if (targetCard == demo1Card) demo2Card else demo1Card
        val refName = if (targetCard == demo1Card) demo2Name else demo1Name
        setCardState(refCard, if (refCard == demo1Card) "DEMO 1" else "DEMO 2  •  OPCIONAL", refName, CardState.LOADED)
        saveAndShare(out, targetName, "startup completo escolhido automaticamente entre as duas demos")
    }

    private fun setStatusNeutral(message: String) {
        status.text = message
        status.setTextColor(white)
        status.background = rounded(card, 14)
    }

    private fun setStatusError(message: String) {
        status.text = "✕  NÃO FOI POSSÍVEL RESTAURAR\n\n$message"
        status.setTextColor(Color.rgb(255, 205, 205))
        status.background = outlined(Color.rgb(48, 18, 20), red, 14, 2)
    }

    private fun replaceAll(src: ByteArray, old: ByteArray, new: ByteArray): Int {
        if (old.isEmpty() || old.size != new.size) return 0
        var count = 0; var p = 0
        while (p <= src.size - old.size) {
            var ok = true
            for (i in old.indices) if (src[p + i] != old[i]) { ok = false; break }
            if (ok) { for (i in new.indices) src[p + i] = new[i]; count++; p += old.size } else p++
        }
        return count
    }

    private fun rebuild(target: ByteArray, ti: Info, reference: ByteArray, ri: Info): ByteArray {
        val startup = reference.copyOfRange(ri.startupOffset, ri.startupOffset + ri.startupLength)
        val oldMap = ("maps/" + ri.map + ".bsp").toByteArray(Charsets.ISO_8859_1)
        val newMap = ("maps/" + ti.map + ".bsp").toByteArray(Charsets.ISO_8859_1)
        if (!ri.map.equals(ti.map, ignoreCase = true)) replaceAll(startup, oldMap, newMap)
        replaceAll(startup, "stop\n".toByteArray(), "echo\n".toByteArray())
        val stream = target.copyOfRange(ti.normalOffset, ti.normalOffset + ti.normalLength)
        val out = ByteArray(216 + startup.size + stream.size + 180)
        target.copyInto(out, 0, 0, 216); startup.copyInto(out, 216); stream.copyInto(out, 216 + startup.size)
        val dv = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        val dir = 216 + startup.size + stream.size
        dv.putInt(212, dir); dv.putInt(dir, 2)
        val d0 = dir + 4
        dv.putInt(d0, 0); dv.putFloat(d0 + 4, 0f); dv.putInt(d0 + 8, 0); dv.putInt(d0 + 12, 216); dv.putInt(d0 + 16, startup.size); dv.putInt(d0 + 20, 0)
        val d1 = d0 + 88
        dv.putInt(d1, 1); dv.putFloat(d1 + 4, ti.time); dv.putInt(d1 + 8, ti.frames); dv.putInt(d1 + 12, 216 + startup.size); dv.putInt(d1 + 16, stream.size); dv.putInt(d1 + 20, 0)
        val mapBytes = ti.map.toByteArray(Charsets.ISO_8859_1)
        java.util.Arrays.fill(out, 20, 84, 0.toByte()); mapBytes.copyInto(out, 20, 0, minOf(63, mapBytes.size))
        java.util.Arrays.fill(out, 84, 148, 0.toByte()); mapBytes.copyInto(out, 84, 0, minOf(63, mapBytes.size))
        return out
    }

    private fun saveAndShare(bytes: ByteArray, originalName: String, method: String) {
        val base = originalName.ifEmpty { "demo.dem" }.replace(Regex("\\.dem$", RegexOption.IGNORE_CASE), "")
        val file = File(cacheDir, base + "_repaired.dem")
        file.writeBytes(bytes)
        setStatusSuccess("DEMO CORRIGIDA!\n\n$method\n\nArquivo pronto: ${file.name}")
        repairButton.finish(true)
        busy = false
        repairButton.isEnabled = true
        val uri = FileProvider.getUriForFile(this, "${BuildConfig.APPLICATION_ID}.fileprovider", file)
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = "application/octet-stream"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Salvar/compartilhar demo corrigida"))
    }

    private fun setStatusSuccess(message: String) {
        status.text = "✓  $message"
        status.setTextColor(Color.rgb(174, 255, 205))
        status.background = outlined(Color.rgb(12, 42, 27), green, 14, 2)
    }

    private fun choose(code: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "application/octet-stream"
            addCategory(Intent.CATEGORY_OPENABLE)
        }, code)
    }

    override fun onActivityResult(req: Int, result: Int, data: Intent?) {
        super.onActivityResult(req, result, data)
        if (result != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        try {
            contentResolver.openInputStream(uri)?.use { input ->
                if (req == pick1) { demo1 = input.readBytes(); demo1Name = displayName(uri); setCardState(demo1Card, "DEMO 1", demo1Name, CardState.LOADED) }
                else { demo2 = input.readBytes(); demo2Name = displayName(uri); setCardState(demo2Card, "DEMO 2  •  OPCIONAL", demo2Name, CardState.LOADED) }
            }
            setStatusNeutral("✓ Demo carregada. Toque em CORRIGIR AUTOMATICAMENTE.")
        } catch (e: Exception) {
            setStatusError("Não consegui ler a demo: ${e.message}")
        }
    }

    private fun displayName(uri: Uri): String = uri.lastPathSegment?.substringAfterLast('/') ?: "demo.dem"

    private data class Info(val map: String, val dir: Int, val startupOffset: Int, val startupLength: Int, val normalOffset: Int, val normalLength: Int, val time: Float, val frames: Int)
    private fun i32(a: ByteArray, o: Int) = ByteBuffer.wrap(a, o, 4).order(ByteOrder.LITTLE_ENDIAN).int
    private fun f32(a: ByteArray, o: Int) = ByteBuffer.wrap(a, o, 4).order(ByteOrder.LITTLE_ENDIAN).float
    private fun text(a: ByteArray, o: Int, n: Int): String {
        var end = o
        while (end < o + n && end < a.size && a[end].toInt() != 0) end++
        return a.copyOfRange(o, end).toString(Charsets.ISO_8859_1)
    }

    private fun info(a: ByteArray): Info {
        require(a.size >= 396) { "Arquivo DEM inválido ou pequeno." }
        val dir = i32(a, 212)
        require(dir >= 216 && dir + 180 <= a.size) { "Diretório da demo inválido." }
        require(i32(a, dir) == 2) { "Diretório inválido: não encontrei 2 entradas." }
        val d0 = dir + 4
        val d1 = d0 + 88
        return Info(text(a, 20, 64), dir, i32(a, d0 + 12), i32(a, d0 + 16), i32(a, d1 + 12), i32(a, d1 + 16), f32(a, d1 + 4), i32(a, d1 + 8))
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun outlined(color: Int, stroke: Int, radius: Int, width: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(width), stroke) }
    private fun lp(w: Int, h: Int, l: Int, t: Int, r: Int, b: Int) = LinearLayout.LayoutParams(w, h).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private class FillButton(context: android.content.Context) : FrameLayout(context) {
        private val fill = View(context)
        private val text = TextView(context)
        var label: String
            get() = text.text.toString()
            set(value) { text.text = value }
        var textSize: Float
            get() = text.textSize / resources.displayMetrics.scaledDensity
            set(value) { text.textSize = value }
        var typeface: Typeface?
            get() = text.typeface
            set(value) { text.typeface = value }
        fun setTextColor(color: Int) { text.setTextColor(color) }
        init {
            clipToOutline = true
            background = GradientDrawable().apply { setColor(Color.rgb(27, 33, 39)); cornerRadius = 16f * resources.displayMetrics.density }
            fill.background = GradientDrawable().apply { setColor(Color.rgb(32, 212, 107)); cornerRadius = 16f * resources.displayMetrics.density }
            addView(fill, LayoutParams(0, -1, Gravity.START))
            text.gravity = Gravity.CENTER
            text.setTextColor(Color.rgb(5, 20, 10))
            addView(text, LayoutParams(-1, -1))
        }
        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            if (w > 0 && fill.layoutParams.width == 0) fill.layoutParams.width = 0
        }
        fun setProgress(progress: Float) {
            val p = progress.coerceIn(0f, 1f)
            fill.layoutParams.width = (width * p).toInt()
            fill.requestLayout()
        }
        fun resetProgress() { setProgress(0f); background = GradientDrawable().apply { setColor(Color.rgb(27, 33, 39)); cornerRadius = 16f * resources.displayMetrics.density } }
        fun finish(success: Boolean) {
            setProgress(1f)
            fill.background = GradientDrawable().apply { setColor(if (success) Color.rgb(32, 212, 107) else Color.rgb(235, 67, 67)); cornerRadius = 16f * resources.displayMetrics.density }
            text.setTextColor(if (success) Color.rgb(5, 20, 10) else Color.WHITE)
            label = if (success) "✓  DEMO CORRIGIDA" else "✕  REPARO FALHOU"
        }
    }

    private fun <T> ValueAnimator.doOnEnd(action: () -> T) {
        addListener(object : android.animation.AnimatorListenerAdapter() { override fun onAnimationEnd(animation: android.animation.Animator) { action() } })
    }
}
