# DemoFix AUTO v11

Corrige demos Xash3D / GoldSrc no celular.

Nesta versão, o som de clique foi corrigido: o app aguarda o carregamento do áudio antes de reproduzi-lo e toca o som nos botões de seleção e correção.
