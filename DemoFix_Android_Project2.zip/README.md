# DemoFix Android

Projeto Android nativo para reparar demos GoldSrc/Xash3D.

## Sem computador
Você pode colocar este projeto em um repositório GitHub pelo celular e usar **Actions > Build DemoFix APK > Run workflow**. O APK aparece em **Artifacts** para baixar.

## Uso do app
Selecione as duas demos da mesma partida. O app escolhe automaticamente a que tem startup completo, usa-a como referência, preserva o gameplay da outra e reconstrói o diretório. Também aplica a correção `stop -> echo`.

Observação: a versão 1 foi criada para o padrão que descobrimos nas demos do usuário. Para casos diferentes, use uma demo referência funcional da mesma sessão.


## Correções desta versão
- Java e Kotlin usam JVM 17 de forma compatível com Gradle/Android Gradle Plugin.
- Diretório Xash3D é reconstruído com 2 entradas e 180 bytes completos (incluindo o contador).
- A leitura do diretório usa corretamente o offset apontado pelo cabeçalho.
